package org.bedu.mascotas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MascotasApplicationTests {

	@Test
	void contextLoads() {
	}

}
